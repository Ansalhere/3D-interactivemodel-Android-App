# Android app to open camera and proceed the 3D view

As a first step in project for showing after effects of liver issues we are opening camera and showing the AR photo.
This android app is the starting of the project and it opens the camera to scan the enviornment.


